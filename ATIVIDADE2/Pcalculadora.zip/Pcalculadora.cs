﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1: Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnSomar_Click(object sender, EventArgs e)
        {
            double Número1 = double.Parse(textNúmero1.Text);
            double Número2 = double.Parse(textNúmero2.Text);
            double Resultado = Número1 + Número2;
            txtResultado.Text = Resultado.ToString();

        }

        private void BtnSubtrair_Click(object sender, EventArgs e)
        {
            double Número1 = double.Parse(textNúmero1.Text);
            double Número2 = double.Parse(textNúmero2.Text);
            double Resultado = Número1 - Número2;
            txtResultado.Text = Resultado.ToString();
        }

        private void BtnMultiplicar_Click(object sender, EventArgs e)
        {
            double Número1 = double.Parse(textNúmero1.Text);
            double Número2 = double.Parse(textNúmero2.Text);
            double Resultado = Número1 * Número2;
            txtResultado.Text = Resultado.ToString();
        }

        private void BtnDividir_Click(object sender, EventArgs e)
        {
            double Número1 = double.Parse(textNúmero1.Text);
            double Número2 = double.Parse(textNúmero2.Text);
            double Resultado = Número1 / Número2;
            txtResultado.Text = Resultado.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textNúmero1.Text = "";
            textNúmero2.Text = "";
            txtResultado.Text = "";
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Close();
        }
    }
}
