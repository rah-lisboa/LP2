﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PNotebook01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lbxNotebook.Items.Clear();
        }

        private void btnExecutar_Click(object sender, EventArgs e)


        {
            double[,] matriz = new double[3, 3];
            double notebook1, notebook2, notebook3;
            double loja1, loja2, loja3;
            double MediaGeralNot = 0;
            for (loja1 = 0; loja1 < 1; loja1++)
            {
                for (  loja2 = 0; loja2 < 2; loja2++)
                {
                    for (  loja3 = 0; loja3 < 3; loja3++)
                    {
                        string input = Interaction.InputBox($"Digite o valor do notebook  . Para a loja1{loja1 + 1} Para a loja2 {loja2}  Para a loja3 {loja3}", "Entrada de Dados:");
                        if (double.TryParse(input, out double valor) && valor >= 0)
                        {
                            matriz [loja1, loja2, loja3] = valor;
                        }
                        else
                        {
                            MessageBox.Show("´Valor inválido");

                        }
                        for (int  MediaGeralNot= 0; MediaGeralNot < 3; MediaGeralNot++)
                        {
                            MediaGeralNot = 0;
                            for (int Loja= 0; Loja < 3; Loja++)
                            {
                                listBox1.Items.Add($"");
                                                             }
                    }

                    }
                }
            }
        }




        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
